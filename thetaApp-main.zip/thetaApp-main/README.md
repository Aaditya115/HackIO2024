# theta

Welcome to Theta. The Safer Way to Drive 

## Getting Started

Developing Repository for the #Theta app, built during HackOHI/O 12 at THE Ohio State University